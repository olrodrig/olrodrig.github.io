####################################
#                                  
# Automatic Loess Regression (ALR) 
#                                  
####################################

The ALR code, written on R, does not require installation, but they have dependencies that must be satisfied.

- R (in Ubuntu: sudo apt-get install r-base)
  these modules have to be installed:
    - R.utils (in Ubuntu: sudo apt-get install r-cran-r.utils)
    - MatrixStats (in Ubuntu: sudo apt-get install r-cran-matrixstats)
    
If you want to run ALR from Python. You have to install:

- Python 3 (recommended) or Python 2.7
  these modules have to be installed:
    - numpy (sudo pip install numpy)
    - rpy2 (sudo pip install rpy2) 
      if you have problems installing rpy2 (e.g., if you have python 2.7), try: sudo pip install rpy2==2.8.6

To run the ALR tutorial, you need to install:

- jupyter (sudo pip install jupyterlab)

Then, in the 'tutorial' folder, open a terminal and run: jupyter notebook


If you use the ALR in your work, please cite:
  Rodríguez et al. 2019, MNRAS, 483, 5459
  Cleveland W. S., Grosse E., Shyu W. M., 1992, in Chambers J. M., Hastie T. J., eds, Statistical models in S. Chapman and Hall, London, p. 309