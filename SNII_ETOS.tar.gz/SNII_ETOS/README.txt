#################################################
#                                  
# SNII Explosion Time from Optical Spectra (ETOS) 
#                                  
#################################################

The SNII_ETOS code does not require installation, but they have dependencies that must be satisfied.

- Python 3 (in Ubuntu: sudo apt-get install python3.6) or Python 2.7
  these modules have to be installed:
    - numpy 1.15.0 or newer (pip3 install numpy)
    - sklearn 0.18.1 or newer (pip3 install scikit-learn) 
    - matplotlib 2.2.4 or newer (pip3 install matplotlib) 

To run the ALR tutorial, you need to install:

- jupyter (pip3 install jupyterlab)

Then, in the 'tutorial' folder, open a terminal and run: jupyter notebook SNII_ETOS_tutorial.ipynb


If you use the SNII_ETOS in your work, please cite:
  Rodríguez et al. 2019, MNRAS, 483, 5459
  Blondin & Tonry 2007, ApJ, 666, 1028
